[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\xampp\htdocs\rallynplc\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>