<?php $__env->startComponent('mail::message'); ?>
# Dear Pejuang NPLC, Kelompok <?php echo e($name); ?>


<?php echo e($mail['message']); ?>


<?php $__env->startComponent('mail::button', ['url' => 'https://forms.gle/R2jEpUF17fJghtuz6']); ?>
Form Daftar Ulang
<?php echo $__env->renderComponent(); ?>

# Pendaftaran ulang paling lambat:
<p><span style="padding-right: 17px">Hari</span>     :  <b>Rabu, 6 November 2019</b></p>
<p><span>Waktu</span>    : <b>23.59 WIB</b></p>

Setelah waktu diatas, peserta akan didiskualifikasi dari babak final 7th NPLC secara otomatis.

Regards,<br>
7th NPLC Team.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\rallynplc\resources\views/ConfirmationEmail.blade.php ENDPATH**/ ?>