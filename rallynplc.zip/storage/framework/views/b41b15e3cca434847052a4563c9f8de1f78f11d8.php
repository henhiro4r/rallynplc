<div class="card shadow mb-4">
    <div class="card-header py-3">
        <div class="row no-gutters">
            <div class="col md-10">
                <h1 class="h4 mb-0 font-weight-bold text-primary" style="margin-top: 0.2em;">Photo List</h1>
            </div>
            <div class="col md-2">
                <button type="button" class="btn btn-dark btn-circle float-right" title="Add New Game" data-toggle="modal"
                        data-target="#addmodal"><i class="fas fa-plus-circle"></i></button>
                <?php echo $__env->make('admin.photo.crud.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if(count($photos) > 0): ?>
                <table class="table table-bordered" id="table" width="100%" cellspacing="0">
                    <thead>
                    <tr class="text-center">
                        <th>Id</th>
                        <th>Title</th>
                        <th>Photo</th>
                        <th>Code</th>
                        <th>Qr Code</th>
                        <th>Value</th>
                        <th>Badge</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td><?php echo e($photo->id); ?></td>
                            <td><?php echo e(ucwords($photo->title)); ?></td>
                            <td><button class="btn btn-info" title="Show Photo" type="button" data-toggle="modal" data-target="#picModal-<?php echo e($photo->id); ?>">Show Photos</button>
                                <?php echo $__env->make('admin.photo.photos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                            <td><?php echo e($photo->code); ?></td>
                            <td><button class="btn btn-info" title="Show QR Code" type="button" data-toggle="modal" data-target="#qrModal-<?php echo e($photo->id); ?>">Show QR Code</button>
                                <?php echo $__env->make('admin.photo.qrcode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                            <td><?php echo e($photo->value); ?></td>
                            <td><?php echo e($photo->badge); ?></td>
                            <td width="150px">
                                <div class="row no-gutters">
                                    <div class="col-md-6">
                                        <button class="btn btn-info btn-circle" title="Edit Game" type="button" data-toggle="modal"
                                                data-target="#editModal-<?php echo e($photo->id); ?>"><i class="fas fa-edit"></i></button>
                                        <?php echo $__env->make('admin.photo.crud.editPhoto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <form action="<?php echo e(route('photo.destroy', $photo->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="DELETE">
                                            <button class="btn btn-danger btn-circle" title="Delete Photo" type="submit"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h1 class="h4 mb-0 font-weight-bold text-primary">No Records</h1>
            <?php endif; ?>
        </div>
    </div>
</div>