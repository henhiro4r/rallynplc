<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php echo $__env->make('inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h1 class="h4 mb-0 font-weight-bold text-primary">Liaison Officer</h1>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <?php if(count($lo) > 0): ?>
                        <table class="table table-bordered" id="table" width="100%" cellspacing="0">
                            <thead>
                            <tr class="text-center">
                                <th>Id</th>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Role</th>
                                <th>PIC of Game</th>
                                <th>Login Status</th>
                                <th>Last Login</th>
                                <th>Last Logout</th>
                                <th>Account Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $lo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($user->id); ?></td>
                                    <td><a href="<?php echo e(route('users.edit', $user->id)); ?>"><?php echo e(ucwords($user->name)); ?></a></td>
                                    <td><?php echo e($user->username); ?></td>
                                    <td><?php echo e(ucwords($user->role->name)); ?></td>
                                    <td><?php echo e($user->detail_id ? ucwords($user->detail->other) : '-'); ?></td>
                                    <td><?php if($user->is_login == '1'): ?> <p class="text-success">Logged in</p> <?php else: ?> <p>Logged Out</p> <?php endif; ?> </td>
                                    <td><?php echo e($user->last_login ? $user->last_login : '-'); ?></td>
                                    <td><?php echo e($user->last_logout ? $user->last_logout : '-'); ?></td>
                                    <td><?php if($user->status == 'E'): ?> <p class="text-success">Enabled</p> <?php else: ?> <p class="text-danger">Disabled</p> <?php endif; ?></td>
                                    <td width="150px">
                                        <div class="row no-gutters">
                                            <div class="col-md-6">
                                                <?php if($user->status == 'E'): ?>
                                                    <form action="<?php echo e(route('user.deactivate')); ?>" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <input name="id" type="hidden" value="<?php echo e($user->id); ?>">
                                                        <button class="btn btn-warning btn-circle" title="Deactivate User" type="submit"><i class="fas fa-exclamation-triangle"></i></button>
                                                    </form>
                                                <?php else: ?>
                                                    <form action="<?php echo e(route('user.activate')); ?>" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <input name="id" type="hidden" value="<?php echo e($user->id); ?>">
                                                        <button class="btn btn-success btn-circle" title="Activate User" type="submit"><i class="fas fa-check"></i></button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input name="_method" type="hidden" value="DELETE">
                                                    <button class="btn btn-danger btn-circle" title="Delete User" type="submit"><i class="fas fa-trash"></i></button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <h1 class="h4 mb-0 font-weight-bold text-primary">No Records</h1>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rallynplc\resources\views/admin/user/list/liaison.blade.php ENDPATH**/ ?>