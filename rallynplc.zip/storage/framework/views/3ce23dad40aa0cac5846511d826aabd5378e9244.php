<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php echo $__env->make('inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h1 class="h4 mb-0 font-weight-bold text-primary">Participant</h1>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <?php if(count($par) > 0): ?>
                        <table class="table table-bordered" id="table" width="100%" cellspacing="0">
                            <thead>
                            <tr class="text-center">
                                <th>Id</th>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Current Point</th>
                                <th>Used Point</th>
                                <th>Login Status</th>
                                <th>Last Login</th>
                                <th>Last Logout</th>
                                <th>Account Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $par; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($user->id); ?></td>
                                    <td><a href="<?php echo e(route('users.edit', $user->id)); ?>"><?php echo e(ucwords($user->name)); ?></a></td>
                                    <td><?php echo e($user->username); ?></td>
                                    <td><?php echo e($user->point_now ? $user->point_now : '0'); ?></td>
                                    <td><?php echo e($user->point_used ? $user->point_used : '0'); ?></td>
                                    <td><?php if($user->is_login == '1'): ?> <p class="text-success">Logged in</p> <?php else: ?> <p>Logged Out</p> <?php endif; ?> </td>
                                    <td><?php echo e($user->last_login ? $user->last_login : '-'); ?></td>
                                    <td><?php echo e($user->last_logout ? $user->last_logout : '-'); ?></td>
                                    <td><?php if($user->status == 'E'): ?> <p class="text-success">Enabled</p> <?php else: ?> <p class="text-danger">Disabled</p> <?php endif; ?></td>
                                    <td width="150px">
                                        <div class="row no-gutters">

                                            <div class="col-md-4">
                                                <button class="btn btn-info btn-circle" title="Details User" type="button" data-toggle="modal"
                                                        data-target="#editModal-<?php echo e($user->id); ?>"><i class="fas fa-edit"></i></button>
                                                <?php echo $__env->make('admin.user.crud.editModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>

                                            <div class="col-md-4">
                                                <?php if($user->status == 'E'): ?>
                                                    <form action="<?php echo e(route('user.deactivate')); ?>" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <input name="id" type="hidden" value="<?php echo e($user->id); ?>">
                                                        <button class="btn btn-warning btn-circle" title="Deactivate User" type="submit"><i class="fas fa-exclamation-triangle"></i></button>
                                                    </form>
                                                <?php else: ?>
                                                    <form action="<?php echo e(route('user.activate')); ?>" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <input name="id" type="hidden" value="<?php echo e($user->id); ?>">
                                                        <button class="btn btn-success btn-circle" title="Activate User" type="submit"><i class="fas fa-check"></i></button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-4">
                                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input name="_method" type="hidden" value="DELETE">
                                                    <button class="btn btn-danger btn-circle" title="Delete User" type="submit"><i class="fas fa-trash"></i></button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <h1 class="h4 mb-0 font-weight-bold text-primary">No Records</h1>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rallynplc\resources\views/admin/user/list/participant.blade.php ENDPATH**/ ?>