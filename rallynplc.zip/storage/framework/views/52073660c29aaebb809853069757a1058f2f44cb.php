<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Content Row -->
        <?php echo $__env->make('inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h1 class="h4 mb-0 font-weight-bold text-primary">Edit <?php echo e($user->role->name .' '. $user->name); ?></h1>
            </div>
            <div class="card body">
                <div class="col-md-12" style="margin-top: 1em;">
                    <form action="<?php echo e(route('users.update', $user->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input name="_method" type="hidden" value="PATCH">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>">
                        </div>
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="username" class="form-control" value="<?php echo e($user->username); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Password...">
                        </div>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" name="password_confirmation" class="form-control" placeholder="Retype Password...">
                        </div>
                        <?php if($user->role_id == 2): ?>
                            <div class="form-group" id="coach">
                                <label>PIC of Game</label>
                                <input name="other" class="form-control" value="<?php echo e($detail->other); ?>">
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <button class="btn btn-primary" type="submit">Edit User</button>
                            <?php if($user->role_id == 1): ?>
                                <a class="btn btn-danger" href="<?php echo e(route('user.admin')); ?>">Cancel</a>
                            <?php elseif($user->role_id == 2): ?>
                                <a class="btn btn-danger" href="<?php echo e(route('user.liaison')); ?>">Cancel</a>
                            <?php elseif($user->role_id == 3): ?>
                                <a class="btn btn-danger" href="<?php echo e(route('user.participant')); ?>">Cancel</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rallynplc\resources\views/admin/user/crud/editGame.blade.php ENDPATH**/ ?>