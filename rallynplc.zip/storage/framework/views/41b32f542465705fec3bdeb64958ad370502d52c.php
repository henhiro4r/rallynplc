<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h1 class="h4 mb-0 font-weight-bold text-primary">History of Photo Taken</h1>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if(count($historys) > 0): ?>
                <table class="table table-bordered" id="table" width="100%" cellspacing="0">
                    <thead>
                    <tr class="text-center">
                        <th>Id</th>
                        <th>Photo Id</th>
                        <th>Photo Title</th>
                        <th>Photo Value</th>
                        <th>Team Name</th>
                        <th>TIme Scan</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $historys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td><?php echo e($history->id); ?></td>
                            <td><?php echo e($history->photo_id); ?></td>
                            <td><a href="<?php echo e(route('photo.show', $history->photo_id)); ?>"><?php echo e($history->photo->title); ?></a></td>
                            <td><?php echo e($history->photo->value); ?></td>
                            <td><a href="<?php echo e(route('users.show', $history->user_id)); ?>"><?php echo e($history->user->name); ?></a></td>
                            <td><?php echo e($history->created_at); ?></td>
                            <td width="150px">
                                <div class="row no-gutters">
                                    <div class="col-md-12">
                                        <form action="<?php echo e(route('historyPhoto.destroy', $history->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="DELETE">
                                            <button class="btn btn-danger btn-circle" title="Delete Game" type="submit"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h1 class="h4 mb-0 font-weight-bold text-primary">No Records</h1>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\rallynplc\resources\views/admin/photo/table/history.blade.php ENDPATH**/ ?>