<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h1 class="h4 mb-0 font-weight-bold text-primary">Games Detail</h1>
            </div>
            <div class="card body">
                <div class="col-md-12" style="margin-top: 1em;">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Game Name</label>
                        </div>
                        <div class="col-md-8">
                            : <b><?php echo e($game->title); ?></b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <label>Game Type</label>
                        </div>
                        <div class="col-md-8">
                            : <?php if($game->type == 'S'): ?> <b class="text-success">Single</b> <?php else: ?> <b class="text-primary">Versus</b> <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <label>Game QRCode</label>
                        </div>
                        <div class="col-md-8">
                            : <button class="btn btn-info" title="Show QR Code" type="button" data-toggle="modal" data-target="#qrModal-<?php echo e($game->id); ?>">Show QR Code</button>
                              <?php echo $__env->make('admin.game.qrcode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <label>Liaison Officer Name</label>
                        </div>
                        <div class="col-md-8">
                            : <b><?php echo e(ucwords($game->user->name)); ?></b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <label>Game Location</label>
                        </div>
                        <div class="col-md-8">
                            : <b><?php echo e(ucwords($game->location)); ?></b>
                        </div>
                    </div>
                    <div class="form-group">
                        <a class="btn btn-danger" href="<?php echo e(route('history.index')); ?>">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rallynplc\resources\views/admin/game/show.blade.php ENDPATH**/ ?>