<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h1 class="h4 mb-0 font-weight-bold text-primary">History of Game Play</h1>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if(count($historys) > 0): ?>
                <table class="table table-bordered" id="table" width="100%" cellspacing="0">
                    <thead>
                    <tr class="text-center">
                        <th>Id</th>
                        <th>Game Id</th>
                        <th>Game Title</th>
                        <th>Game Type</th>
                        <th>Team A</th>
                        <th>Result Team A</th>
                        <th>Team B</th>
                        <th>Result Team B</th>
                        <th>Game Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $historys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td><?php echo e($history->id); ?></td>
                            <td><?php echo e($history->game_id); ?></td>
                            <td><a href="<?php echo e(route('games.show', $history->game_id)); ?>"><?php echo e($history->game->title); ?></a></td>
                            <td><?php if($history->game->type == 'S'): ?> <p class="text-success">Single</p> <?php else: ?> <p class="text-primary">Versus</p> <?php endif; ?> </td>
                            <td><a href="<?php echo e(route('users.show', $history->teamA)); ?>"><?php echo e($history->teamName($history->teamA)); ?></a></td>
                            <td><?php echo e($history->resultA .' ('.$history->pointA.')'); ?></td>
                            <td><a href="<?php echo e(route('users.show', $history->teamB)); ?>"><?php echo e($history->teamName($history->teamB)); ?></a></td>
                            <td><?php echo e($history->resultB .' ('.$history->pointB.')'); ?></td>
                            <td><?php if($history->is_done == '0'): ?> <p class="text-warning">Playing</p> <?php else: ?> <p class="text-success">Finished</p> <?php endif; ?> </td>
                            <td width="150px">
                                <div class="row no-gutters">
                                    <div class="col-md-6">
                                        <button class="btn btn-info btn-circle" title="Edit Game" type="button" data-toggle="modal"
                                                data-target="#editModal-<?php echo e($history->id); ?>"><i class="fas fa-edit"></i></button>
                                        <?php echo $__env->make('admin.game.crud.editHistory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <form action="<?php echo e(route('history.destroy', $history->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="DELETE">
                                            <button class="btn btn-danger btn-circle" title="Delete Game" type="submit"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h1 class="h4 mb-0 font-weight-bold text-primary">No Records</h1>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\rallynplc\resources\views/admin/game/table/history.blade.php ENDPATH**/ ?>