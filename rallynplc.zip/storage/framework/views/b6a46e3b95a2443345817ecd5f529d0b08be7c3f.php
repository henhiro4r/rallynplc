<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h1 class="h4 mb-0 font-weight-bold text-primary">History of Quiz Play</h1>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if(count($historys) > 0): ?>
                <table class="table table-bordered" id="table" width="100%" cellspacing="0">
                    <thead>
                    <tr class="text-center">
                        <th>Id</th>
                        <th>Quiz Id</th>
                        <th>Quiz Title</th>
                        <th>Team Name</th>
                        <th>Chance Remaining</th>
                        <th>Is Right</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $historys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td><?php echo e($history->id); ?></td>
                            <td><?php echo e($history->quiz_id); ?></td>
                            <td><a href="<?php echo e(route('quiz.show', $history->quiz_id)); ?>"><?php echo e($history->quiz->title); ?></a></td>
                            <td><a href="<?php echo e(route('users.show', $history->user_id)); ?>"><?php echo e($history->user->name); ?></a></td>
                            <td><?php echo e($history->try); ?></td>
                            <td><?php if($history->is_right == '0'): ?> <p class="text-danger">False</p> <?php else: ?> <p class="text-success">True</p> <?php endif; ?> </td>
                            <td width="150px">
                                <div class="row no-gutters">
                                    <div class="col-md-6">
                                        <button class="btn btn-info btn-circle" title="Edit Game" type="button" data-toggle="modal"
                                                data-target="#editModal-<?php echo e($history->id); ?>"><i class="fas fa-edit"></i></button>
                                        <?php echo $__env->make('admin.quiz.crud.editHistory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <form action="<?php echo e(route('historyQuiz.destroy', $history->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="DELETE">
                                            <button class="btn btn-danger btn-circle" title="Delete Game" type="submit"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h1 class="h4 mb-0 font-weight-bold text-primary">No Records</h1>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\rallynplc\resources\views/admin/quiz/table/history.blade.php ENDPATH**/ ?>