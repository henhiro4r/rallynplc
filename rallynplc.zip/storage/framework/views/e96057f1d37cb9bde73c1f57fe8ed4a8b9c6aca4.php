<!-- The Modal -->
<div class="modal fade" id="qrModal-<?php echo e($game->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><?php echo e($game->title); ?> QR Code</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body" style="text-align: left;">
                <div class="text-center py-2">
                    <img src="<?php echo e(asset('images/games/'.$game->qr_code)); ?>" height="300" class="img-profile" id="qrcode">
                </div>
            </div>
            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\rallynplc\resources\views/admin/game/qrcode.blade.php ENDPATH**/ ?>