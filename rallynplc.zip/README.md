# Rally NPLC
Rally NPLC Admin Website

#Instruction Before Cloning this project
1. Make sure your xampp or wampp already on latest version because this project use Laravel 6.0 and require PHP 7.2.0
2. Open project folder and run git bash terminal
3. Run this following command in bash terminal 
    - composer install
    - cp .env.example .env
    - php artisan key:generate
    - setup .env file
    - php artisan migrate --seed
    - open in browser
4. You also can follow steps in this website "https://devmarketer.io/learn/setup-laravel-project-cloned-github-com/"
